public interface IFuncion {
    double calcularDescuento(); // Método para calcular el descuento
    String getNombre(); // Obtener el nombre de la función
    double getPrecio(); // Obtener el precio de la función
    void setPrecio(double precio);
}
