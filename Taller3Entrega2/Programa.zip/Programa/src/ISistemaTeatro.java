import java.util.List;
public interface ISistemaTeatro {
    void cargarFunciones(List<IFuncion> funciones); // Cargar lista de funciones
    void mostrarFuncionesDisponibles(); // Mostrar funciones disponibles
    IFuncion buscarFuncion(int codigo); // Buscar función por código
    void agregarUsuario(Usuario usuario); // Agregar un usuario al sistema
    void generarEstadisticas(); // Generar estadísticas del sistema
}
