import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        ContenedorUsuario contenedorUsuario = new ContenedorUsuario();
        ContenedorTeatro contenedorTeatro = new ContenedorTeatro();
        Estadistica estadistica = new Estadistica();

        cargarFuncionesDesdeArchivo("funciones.txt", contenedorTeatro);

        while (true) {
            System.out.println("\nBienvenido al Teatro de Antofagasta");
            System.out.println("1. Registrarse");
            System.out.println("2. Iniciar Sesión");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    registrarUsuario(scanner, contenedorUsuario);
                    break;
                case 2:
                    iniciarSesion(scanner, contenedorUsuario, contenedorTeatro, estadistica);
                    break;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }
        }
    }

    private static void cargarUsuariosDesdeArchivo(String archivo, ContenedorUsuario contenedorUsuarios) {
        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");
                String rut = datos[0];
                String contrasena = datos[1];
                boolean esMiembro = Boolean.parseBoolean(datos[2]);
                contenedorUsuarios.agregarUsuario(new Usuario(rut, contrasena, esMiembro));
            }
        } catch (IOException e) {
            System.out.println("No se pudo cargar el archivo de usuarios: " + e.getMessage());
        }
    }

    private static void cargarFuncionesDesdeArchivo(String archivo, ContenedorTeatro contenedorFunciones) {
        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");
                int codigo = Integer.parseInt(datos[0]);
                String nombre = datos[1];
                int duracion = Integer.parseInt(datos[2]);
                double precio = Double.parseDouble(datos[3]);
                String horario = datos[4];
                String atributo1 = datos[5];
                String atributo2 = datos[6];

                if (codigo >= 100 && codigo <= 199) {
                    // Película
                    boolean nominadaOscar = atributo2.equalsIgnoreCase("si");
                    contenedorTeatro.agregarTeatros(new Pelicula(codigo, nombre, duracion, precio, horario, atributo1, nominadaOscar));
                } else if (codigo >= 200 && codigo <= 299) {
                    // Obra de Teatro
                    String autor = atributo1;
                    int cantidadActos = Integer.parseInt(atributo2);
                    contenedorTeatro.agregarTeatros(new ObraTeatro(codigo, nombre, duracion, precio, horario, autor, cantidadActos));
                } else if (codigo >= 300 && codigo <= 399) {
                    // Documental
                    String tema = atributo1;
                    int anioProduccion = Integer.parseInt(atributo2);
                    contenedorFunciones.agregarFuncion(new Documental(codigo, nombre, duracion, precio, horario, tema, anioProduccion));
                }
            }
        } catch (IOException e) {
            System.out.println("No se pudo cargar el archivo de funciones: " + e.getMessage());
        }
    }
    private static void registrarUsuario(Scanner scanner, ContenedorUsuario contenedorUsuarios) {
        System.out.println("\n--- Registro de Usuario ---");
        System.out.print("Ingrese su RUT: ");
        String rut = scanner.nextLine();
        System.out.print("Ingrese su contraseña: ");
        String contrasena = scanner.nextLine();

        if (contenedorUsuarios.agregarUsuarios(new Usuario(rut, contrasena, false))) {
            System.out.println("Usuario registrado con éxito.");
        } else {
            System.out.println("El usuario ya está registrado.");
        }
    }

    private static void iniciarSesion(Scanner scanner, ContenedorUsuario contenedorUsuarios, ContenedorTeatro contenedorFunciones, Estadistica estadisticas) {
        System.out.println("\n--- Inicio de Sesión ---");
        System.out.print("Ingrese su RUT: ");
        String rut = scanner.nextLine();
        System.out.print("Ingrese su contraseña: ");
        String contrasena = scanner.nextLine();

        Usuario usuario = contenedorUsuario.buscarUsuarios(rut, contrasena);
        if (usuario != null) {
            System.out.println("Inicio de sesión exitoso. Bienvenido, " + rut);
            mostrarMenuPrincipal(scanner, usuario, contenedorTeatro, estadisticas);
        } else {
            System.out.println("Credenciales incorrectas.");
        }
    }

    private static void mostrarMenuPrincipal(Scanner scanner, Usuario usuario, ContenedorTeatro contenedorTeatros, Estadistica estadisticas) {
        while (true) {
            System.out.println("\n--- Menú Principal ---");
            System.out.println("1. Comprar Entradas");
            System.out.println("2. Ver Funciones Disponibles");
            System.out.println("3. Buscar una Función");
            System.out.println("4. Cerrar Sesión");
            System.out.print("Seleccione una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir salto de línea

            switch (opcion) {
                case 1:
                    contenedorTeatros.comprarEntradas(scanner, usuario, estadisticas);
                    break;
                case 2:
                    contenedorTeatros.mostrarFuncionesDisponibles();
                    break;
                case 3:
                    contenedorTeatros.buscarFuncion(scanner);
                    break;
                case 4:
                    System.out.println("Sesión cerrada. Volviendo al menú inicial...");
                    return;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }
        }
    }


}