public class Sala {
    private boolean[][] asientos = new boolean[5][5]; // 5 filas y 5 columnas

    public void mostrarAsientos() {
        for (int i = 0; i < asientos.length; i++) {
            for (int j = 0; j < asientos[i].length; j++) {
                System.out.print(asientos[i][j] ? "[X]" : "[O]");
            }
            System.out.println();
        }
    }

    public boolean ocuparAsiento(int fila, int columna) {
        if (!asientos[fila][columna]) {
            asientos[fila][columna] = true;
            return true;
        }
        return false; // Asiento ya ocupado
    }

    public int getAsientosDisponibles() {
        int disponibles = 0;
        for (int i = 0; i < asientos.length; i++) {
            for (int j = 0; j < asientos[i].length; j++) {
                if (!asientos[i][j]) {
                    disponibles++;
                }
            }
        }
        return disponibles;
    }
}
