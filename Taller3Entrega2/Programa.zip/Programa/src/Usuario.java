public class Usuario {
    private String rut;
    private String contrasena;
    private boolean esMiembro;

    public Usuario(String rut, String contrasena, boolean esMiembro) {
        this.rut = rut;
        this.contrasena = contrasena;
        this.esMiembro = esMiembro;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public boolean isEsMiembro() {
        return esMiembro;
    }

    public void setEsMiembro(boolean esMiembro) {
        this.esMiembro = esMiembro;
    }
}
