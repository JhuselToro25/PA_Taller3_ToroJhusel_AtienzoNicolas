public class Documental extends Funcion {
    private String tema;
    private int anioProduccion;


    public Documental(int codigo, String nombre, int duracion, double precio, String horario, Sala sala, String tema, int anioProduccion) {
        super(codigo, nombre, duracion, precio, horario, sala);
        this.tema = tema;
        this.anioProduccion = anioProduccion;
    }

    @Override
    public double calcularDescuento() {
        return precio * 0.75; // Descuento fijo del 25% para documentales
    }

    public String getTema() {
        return tema;
    }

    public void setTema(String tema) {
        this.tema = tema;
    }

    public int getAnioProduccion() {
        return anioProduccion;
    }

    public void setAnioProduccion(int anioProduccion) {
        this.anioProduccion = anioProduccion;
    }
}
