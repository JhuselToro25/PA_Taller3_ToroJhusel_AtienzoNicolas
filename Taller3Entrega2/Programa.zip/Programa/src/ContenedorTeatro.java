import java.util.ArrayList;
import java.util.List;

public class ContenedorTeatro {
    private List<IFuncion> funciones; // Lista de funciones
    private int cantidadMaxima;
    private int cantidadMinima;

    public ContenedorTeatro(int cantidadMaxima) {
        this.funciones = new ArrayList<>();
        this.cantidadMaxima = cantidadMaxima;
        this.cantidadMinima = 0;
    }
    public boolean agregar(IFuncion nuevaFuncion) {
        if (funciones.size() < cantidadMaxima) {
            funciones.add(nuevaFuncion);
            return true;
        } else {
            System.out.println("No se puede agregar más funciones. Capacidad máxima alcanzada.");
            return false;
        }
    }

    public IFuncion obtener(int posicion) {
        if (posicion >= 0 && posicion < funciones.size()) {
            return funciones.get(posicion);
        } else {
            System.out.println("Posición no válida.");
            return null;
        }
    }

    public int getCantidadActual() {
        return funciones.size();
    }

    public void unirseClub() {
        System.out.println("¡Bienvenido al Club del Teatro!");
    }
}