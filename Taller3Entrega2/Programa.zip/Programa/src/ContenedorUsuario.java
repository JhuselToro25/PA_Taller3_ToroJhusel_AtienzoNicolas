import java.util.ArrayList;
import java.util.List;

public class ContenedorUsuario {
    private List<Usuario> usuarios; // Lista de usuarios
    private int cantidadMaxima;
    private int cantidadActual;

    public ContenedorUsuario(int cantidadMaxima) {
        this.usuarios = new ArrayList<>();
        this.cantidadMaxima = cantidadMaxima;
        this.cantidadActual = 0;
    }

    public boolean agregar(Usuario nuevoUsuario) {
        if (cantidadActual < cantidadMaxima) {
            usuarios.add(nuevoUsuario);
            cantidadActual++;
            return true;
        } else {
            System.out.println("No se puede agregar más usuarios. Capacidad máxima alcanzada.");
            return false;
        }
    }

    public Usuario buscar(String rut) {
        for (Usuario usuario : usuarios) {
            if (usuario.getRut().equals(rut)) {
                return usuario;
            }
        }
        System.out.println("Usuario no encontrado.");
        return null;
    }

    public int getCantidadActual() {
        return cantidadActual;
    }
}