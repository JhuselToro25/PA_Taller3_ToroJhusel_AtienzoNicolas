public class ObraTeatro extends Funcion {
    private String autor;
    private int cantidadActos;

    public ObraTeatro(int codigo, String nombre, int duracion, double precio, String horario, Sala sala, String autor, int cantidadActos) {
        super(codigo, nombre, duracion, precio, horario, sala);
        this.autor = autor;
        this.cantidadActos = cantidadActos;
    }

    @Override
    public double calcularDescuento() {
        return precio * 0.85; // Descuento fijo del 15% para obras de teatro
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getCantidadActos() {
        return cantidadActos;
    }

    public void setCantidadActos(int cantidadActos) {
        this.cantidadActos = cantidadActos;
    }

}
