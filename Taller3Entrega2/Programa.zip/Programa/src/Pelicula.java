public class Pelicula extends Funcion {
    private int codigo;
    private String nombre;
    private int duracion; // en minutos
    private double precio;
    private String horario;
    private Sala sala;
    private String genero;
    private boolean nominadaOscar;

    public Pelicula(int codigo, String nombre, int duracion, double precio, String horario, Sala sala, String genero, boolean nominadaOscar) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.duracion = duracion;
        this.precio = precio;
        this.horario = horario;
        this.sala = sala;
        this.genero = genero;
        this.nominadaOscar = nominadaOscar;
    }

    @Override
    public double calcularDescuento() {
        return nominadaOscar ? precio * 0.8 : precio * 0.9; // 20% si está nominada, 10% si no
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public double getPrecio() {
        return precio;
    }

    @Override
    public void setPrecio(double precio) {
        this.precio = precio;
    }
}
