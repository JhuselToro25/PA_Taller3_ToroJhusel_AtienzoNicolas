import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SistemaTeatro implements ISistemaTeatro {
    private List<Usuario> usuarios;
    private Map<Integer, IFuncion> funciones;

    // Constructor
    public SistemaTeatro() {
        usuarios = new ArrayList<>();
        funciones = new HashMap<>();
    }

    @Override
    public void cargarFunciones(List<IFuncion> funciones) {
        for (IFuncion funcion : funciones) {
            this.funciones.put(funcion.hashCode(), funcion); // Usar el hashCode como identificador único
        }
    }

    @Override
    public void mostrarFuncionesDisponibles() {
        for (IFuncion funcion : funciones.values()) {
            System.out.println("Función: " + funcion.getNombre() + ", Precio: " + funcion.getPrecio());
        }
    }

    @Override
    public IFuncion buscarFuncion(int codigo) {
        return funciones.get(codigo); // Buscar función por su código
    }

    @Override
    public void agregarUsuario(Usuario usuario) {
        usuarios.add(usuario);
    }

    @Override
    public void generarEstadisticas() {
        System.out.println("Total de usuarios registrados: " + usuarios.size());
        System.out.println("Total de funciones disponibles: " + funciones.size());
    }
}