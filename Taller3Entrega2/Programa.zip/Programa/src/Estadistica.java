import java.util.List;

public class Estadistica {
    private int totalEntradasVendidas;
    private int usuariosClub;
    private IFuncion funcionMasPopular;
    private String tipoFuncionMasPopular;
    private float ingresosNoche;
    private float ingresosTotales;

    // Constructor
    public Estadistica() {
        this.totalEntradasVendidas = 0;
        this.usuariosClub = 0;
        this.funcionMasPopular = null;
        this.tipoFuncionMasPopular = "";
        this.ingresosNoche = 0;
        this.ingresosTotales = 0;
    }

    // Incrementar el total de entradas vendidas
    public void incrementarEntradasVendidas(int cantidad) {
        this.totalEntradasVendidas += cantidad;
    }

    // Calcular la función más popular
    public void calcularFuncionMasPopular(List<IFuncion> listaFunciones) {
        if (listaFunciones.isEmpty()) return;

        IFuncion masPopular = null;
        int mayorAsistencia = 0;

        for (IFuncion funcion : listaFunciones) {
            if (funcion instanceof Pelicula) { // Ejemplo: Simulamos asistencia según tipo
                mayorAsistencia += 50;
            } else if (funcion instanceof ObraTeatro) {
                mayorAsistencia += 30;
            } else if (funcion instanceof Documental) {
                mayorAsistencia += 20;
            }
            masPopular = funcion;
        }
        this.funcionMasPopular = masPopular;
        this.tipoFuncionMasPopular = masPopular.getClass().getSimpleName();
    }

    public void calcularIngresosTotales(List<IFuncion> listaFunciones) {
        this.ingresosTotales = 0;
        for (IFuncion funcion : listaFunciones) {
            this.ingresosTotales += funcion.getPrecio();
        }
    }

    public void mostrarEstadisticas() {
        System.out.println("Total Entradas Vendidas: " + totalEntradasVendidas);
        System.out.println("Usuarios del Club: " + usuariosClub);
        System.out.println("Función Más Popular: " + (funcionMasPopular != null ? funcionMasPopular.getNombre() : "Ninguna"));
        System.out.println("Tipo de Función Más Popular: " + tipoFuncionMasPopular);
        System.out.println("Ingresos Totales: " + ingresosTotales);
    }
}
